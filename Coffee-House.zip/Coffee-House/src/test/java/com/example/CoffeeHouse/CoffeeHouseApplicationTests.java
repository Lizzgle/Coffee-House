package com.example.CoffeeHouse;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CoffeeHouseApplicationTests {

	@Test
	void contextLoads() {
	}

}
